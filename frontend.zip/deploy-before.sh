
if [ -d /home/ec2-user/solcast-frontend ]; then
    sudo rm -rf /home/ec2-user/solcast-frontend/
fi
sudo mkdir -vp /home/ec2-user/solcast-frontend/
